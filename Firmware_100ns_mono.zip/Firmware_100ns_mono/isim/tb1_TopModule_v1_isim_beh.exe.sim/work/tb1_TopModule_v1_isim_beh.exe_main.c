/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    unisims_ver_m_00000000003003270080_0848181053_init();
    unisims_ver_m_00000000002122201514_0226517793_init();
    unisims_ver_m_00000000000993192522_2060149708_init();
    work_m_00000000002015455456_0636115572_init();
    work_m_00000000002658536268_1742713452_init();
    work_m_00000000002727190570_2423714012_init();
    work_m_00000000004218551397_2153656397_init();
    work_m_00000000003594558500_0309543917_init();
    work_m_00000000000469054460_0143817880_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000000469054460_0143817880");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
